A collection of non-medical item animations, models and textures.
As many items as possible were converted to fancier gunslinger animations. Some items had their use sounds replaced/enhanced.
Items that lacked animations now have them.

Originally made/adapted for ⁠Body Health System realistic overhaul by me, but separated out into a separate mod.

Fully DLTX.

Credits: 
Warhawk022 for some textures.
Apathy_Knight for water flask rework, used for metal flask and quality vodka animations.
